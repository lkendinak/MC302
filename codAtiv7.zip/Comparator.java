package Ativ7;

public interface Comparator <Type> {
	public boolean precede(Type a, Type b);

}
